/*
 *  perlin.cpp
 *  Practica1
 *
 *  Created by Alejandro Ribao on 11/03/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "perlin.h"


/********************************************************************
 
 Funciones para calcular el ruido Perlin en cada punto
 
 /********************************************************************/

/*
 Pseudo random
 */
float Noise(register int x)
{
    x = (x<<13)^x;
    float r = (((x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483648.0);
	
	return r;
}



/*
 Interpolacion
 */
float InterPol(float a, float b, float x){     //a altura 1a
    return a+(b-a)*x*x*(3-2*x);                //b altura 2a
}                            //c si = 0 entonces a, si = 1 entonces b




/*
 Ruido Perlin para la posicion x,y
 */
float PerlinNoise(float x,float y,int width,int octaves,float seed, float persistence){
	double a,b,valor=0,freq,cachox,cachoy;
	int casilla,num_pasos,pasox,pasoy;
	float amplitud=256*persistence;            //La amplitud es 128,64,32,16... para cada pasada
	float periodo=256;                         //El periodo es similar a la amplitud
	if (octaves>12) 
		octaves=12;
	
	
	for (int s=0;s<octaves;s++){
		amplitud/=2;                      
		periodo/=2;
		freq=1/float(periodo);             //Optimizacion para dividir 1 vez y multiplicar luego
		num_pasos=int(width*freq);         //Para el const que vimos en IntNoise
		pasox=int(x*freq);                 //Indices del vértice superior izquerda del cuadrado
		pasoy=int(y*freq);                 //en el que nos encontramos
		cachox=x*freq-pasox;               //frac_x y frac_y en el ejemplo
		cachoy=y*freq-pasoy;
		casilla=pasox+pasoy*num_pasos;     // índice final del IntNoise
		a=InterPol(Noise(casilla+seed),Noise(casilla+1+seed),cachox);
		b=InterPol(Noise(casilla+num_pasos+seed),Noise(casilla+1+num_pasos+seed),cachox);
		valor+=InterPol(a,b,cachoy)*amplitud;   //superposicion del valor final con anteriores
	}
	
	return valor;      
	
}





/*
 Funcion para generar Ruido Perlin con unas dimensiones determinadas
 */
int** genPerlinNoise (int size, int octaves, int seed, float persistence){
	int** tabla;
	
	tabla = new int*[size];
	
	for (int x=0; x<size; x++){
		tabla[x] = new int[size];
		for (int y=0; y<size; y++){
			tabla[x][y] = int (PerlinNoise(x,y,size,octaves, seed, persistence));
		}
	}	
	return tabla;
}









/********************************************************************
 
 Funciones para normalizar la imagen
 
 /********************************************************************/

/*
 Para enteros
 */
void normalizarInt(int** tabla, int size){
	int maxv = -1000;
	int minv = 9999;
	int rango;
	float factor;
	
	for (int x=0; x<size; x++){
		for (int y=0; y<size; y++){
			if (tabla[x][y] > maxv)
				maxv = tabla[x][y];
			if (tabla[x][y] <  minv)
				minv = tabla[x][y];
		}
	}
	
	rango = maxv-minv;
	factor = 255.0/rango;
	
	for (int x=0; x<size; x++){
		for (int y=0; y<size; y++){
			tabla[x][y] = (tabla[x][y]-minv) * factor;
		}
	}
	
}


/*
 Para float
 */
void normalizarFloat(float** tabla, int size){
	int maxv = -1000;
	int minv = 9999;
	float rango;
	float factor;
	
	for (int x=0; x<size; x++){
		for (int y=0; y<size; y++){
			if (tabla[x][y] > maxv)
				maxv = tabla[x][y];
			if (tabla[x][y] <  minv)
				minv = tabla[x][y];
		}
	}
	
	cerr << "max: " << maxv << " min: " << minv << endl; 
	
	rango = maxv-minv;
	factor = 1.0/rango;
	
	for (int x=0; x<size; x++){
		for (int y=0; y<size; y++){
			tabla[x][y] = (tabla[x][y]-minv) * factor;
		}
	}
	
}






/********************************************************************
 
 Funciones para escribir por pantalla el archivo PGM
 
 /********************************************************************/
/*
 Para enteros
 */
void printTablaInt ( int** tabla, int size ){
	cout << "P2"<< endl << size << " "<< size << endl << "255" << endl;
	
	for (int x=0; x<size; x++){
		for (int y=0; y<size; y++){
			cout << int(tabla[x][y]) << " ";	
		}
		cout << endl;
	}
}


/*
 Para floats
 */
void printTablaFloat ( float** tabla, int size ){
	cout << "P2"<< endl << size << " "<< size << endl << "255" << endl;
	
	for (int x=0; x<SIZE; x++){
		for (int y=0; y<SIZE; y++){
			cout << int(tabla[x][y]) << " ";	
		}
		cout << endl;
	}
	
}





/********************************************************************
 
 Funcionpara leer un archivo PGM
 
 /********************************************************************/

int** readPGM ( char* filename ){
	ifstream fich1;
	int** tablaAux;
	
	char readed[15];
	int n;
	
	fich1.open(filename, ios::in | ios::binary);
	
	if ( !fich1.is_open() ){
		cout << "No se ha podido abrir el archivo:"<< fich1 << endl;
		exit(1);
	}
	
	do {
		fich1 >> readed;	
	} while (strcmp(readed,"P2"));
	
	do {
		fich1 >> readed;	
	} while (readed[0]=='#');
	
	fich1 >> n;
	fich1 >> n;
	
	tablaAux = new int*[n];
	for (int i=0; i<n; i++){
		tablaAux[i] = new int[n];
	}
	
	for (int i=0; i<n; i++){
		for (int j=0; j<n; j++){
			fich1 >> tablaAux[i][j];
		}
	}
	
	fich1.close();
	
	return tablaAux;
}




/********************************************************************
 
 Funciones para escribir en archivo PGM la imagen
 
 /********************************************************************/
/*
 Para enteros
 */
void writePGMint ( char* filename, int** tabla, int size ){
	ofstream fich1;
	
	fich1.open(filename, ios::out | ios::binary);
	
	if ( !fich1.is_open() ){
		cout << "No se ha podido crear el archivo:"<< fich1 << endl;
		exit(1);
	}
	
	fich1 << "P2"<< endl << "# log.ppm"<< endl << size << " "<< size << endl << "255" << endl;
	
	for (int i=0; i<size; i++){
		for (int j=0; j<size; j++){
			fich1 << tabla[i][j] << " ";
		}
		fich1 << endl;
	}
	
	fich1.close();
} 


/*
 Para floats
 */
void writePGMfloat ( char* filename, float** tabla, int size ){
	int** tablatemp = float2int(tabla, size);
	
	writePGMint(filename, tablatemp, size);
	
	freeTablaInt(tablatemp, size);
} 




/********************************************************************
 
 Conversion del espacio de [0,255] a [0,1] y viceversa
 
 /********************************************************************/

/*
 De 0,255 a 0,1
 */
float** int2float ( int** tabla, int size ){
	float** tablaOut;
	
	tablaOut = new float*[size];
	
	for (int x=0; x<size; x++){
		tablaOut[x] = new float[size];
		for (int y=0; y<size; y++){
			tablaOut[x][y] = tabla[x][y] / 255.0;
		}
	}
	
	return tablaOut;
}


/*
 De 0,1 a 0,255
 */
int** float2int ( float** tabla, int size ){
	int** tablaOut;
	
	tablaOut = new int*[size];
	
	for (int x=0; x<size; x++){
		tablaOut[x] = new int[size];
		for (int y=0; y<size; y++){
			tablaOut[x][y] = int (tabla[x][y] * 255);
		}
	}
	
	return tablaOut;
}





/********************************************************************
 
 Funcion para liberar la memoria ocupada por la imagen
 
 /********************************************************************/
/*
 Para enteros
 */
void freeTablaInt(int** tabla, int size){
	for (int i=0; i<size; i++){
		delete[] tabla[i];
	}
	delete[] tabla;
}


/*
 Para floats
 */
void freeTablaFloat(float** tabla, int size){
	for (int i=0; i<size; i++){
		delete[] tabla[i];
	}
	delete[] tabla;
}



