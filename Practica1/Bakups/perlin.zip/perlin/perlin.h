/*
 *  perlin.h
 *  Practica1
 *
 *  Created by Alejandro Ribao on 11/03/08.
 *  2008
 *
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>

// Based on http://freespace.virgin.net/hugo.elias/models/m_perlin.htm
// and http://pgrafica.webideas4all.com/perlin.html

using namespace std;
const int SIZE = 256;



/********************************************************************
 
 Funciones para calcular el ruido Perlin en cada punto
 
 /********************************************************************/

/*
 Pseudo random
 */
float Noise(register int x);
/*
 Interpolacion
 */
float InterPol(float a, float b, float x);
/*
 Ruido Perlin para la posicion x,y
 */
float PerlinNoise(float x,float y,int width,int octaves,float seed, float persistence);
/*
 Funcion para generar Ruido Perlin con unas dimensiones determinadas
 */
int** genPerlinNoise (int size, int octaves, int seed, float persistence);




/********************************************************************
 
 Funciones para normalizar la imagen
 
 /********************************************************************/

/*
 Para enteros
 */
void normalizarInt(int** tabla, int size);
/*
 Para float
 */
void normalizarFloat(float** tabla, int size);






/********************************************************************
 
 Funciones para escribir por pantalla el archivo PGM
 
 /********************************************************************/
/*
 Para enteros
 */
void printTablaInt ( int** tabla, int size );


/*
 Para floats
 */
void printTablaFloat ( float** tabla, int size );





/********************************************************************
 
 Funcionpara leer un archivo PGM
 
 /********************************************************************/

int** readPGM ( char* filename );



/********************************************************************
 
 Funciones para escribir en archivo PGM la imagen
 
 /********************************************************************/
/*
 Para enteros
 */
void writePGMint ( char* filename, int** tabla, int size );


/*
 Para floats
 */
void writePGMfloat ( char* filename, float** tabla, int size );




/********************************************************************
 
 Conversion del espacio de [0,255] a [0,1] y viceversa
 
 /********************************************************************/

/*
 De 0,255 a 0,1
 */
float** int2float ( int** tabla, int size );


/*
 De 0,1 a 0,255
 */
int** float2int ( float** tabla, int size );





/********************************************************************
 
 Funcion para liberar la memoria ocupada por la imagen
 
 /********************************************************************/
/*
 Para enteros
 */
void freeTablaInt(int** tabla, int size);

/*
 Para floats
 */
void freeTablaFloat(float** tabla, int size);


